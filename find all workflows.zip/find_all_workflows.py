import requests
from bs4 import BeautifulSoup
import json
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from time import time



# Initialize the Selenium web driver
service = Service('./chromedriver')
driver = webdriver.Chrome(service=service)
count=1
counter = 0
def crawl(url, visited_links, current_workflow, found_workflows,counter,count):
    count
    # Check if the URL has already been visited
    if url.startswith('http') and counter>1:
        # it is external
        return
        counter+=1
    if url in visited_links:
        # Add the current workflow to the list of found workflows
        found_workflows.append(current_workflow.copy())
        f = open("workflows.json", "a")
        f.write(json.dumps(found_workflows))
        f.write("\n")
        f.close()
        # Remove the current link from the current workflow and return
        if(len(current_workflow)!=0):
            current_workflow.pop()
        return

    # Add the URL to the set of visited links
    visited_links.add(url)

    # Add the default protocol if none is supplied
    if not url.startswith('http'):
        url = base_url+ url

    # Send an HTTP request to the URL and retrieve the response
    response = requests.get(url)

    # Parse the HTML content of the response using BeautifulSoup
    soup = BeautifulSoup(response.content, 'html.parser')

    # Find all links on the page
    links = soup.find_all('a',href=True)
    # print(links)


    # If there are no new links, add the current workflow to the list of found workflows
    if not links:
        found_workflows.append(current_workflow.copy())
        f = open("workflows.json", "a")
        f.write(json.dumps(found_workflows))
        f.write("\n")
        f.close()
        if(len(current_workflow)!=0):
            current_workflow.pop()
        return

    # Loop through new links and add them to the current workflow and visited links
    for link in links:
        new_url = link.get('href')
        # print(new_url)
        if new_url and new_url not in visited_links:
            current_workflow.append(new_url)

            # get a screenshot when a new url is added to the current workflow
            driver.get(base_url+new_url)
            filename = str(count) + '.png'
            driver.save_screenshot(filename)
            count+=1
            driver.implicitly_wait(1)

            # Recursively crawl the new link
            crawl(new_url, visited_links, current_workflow, found_workflows,counter,count)
            # Remove the new link from the current workflow
            if(len(current_workflow)!=0):
                current_workflow.pop()

    # If the current workflow is empty, add an empty list to the found workflows
    if not current_workflow:
        found_workflows.append([])


# Example usage
visited_links = set()
current_workflow = []
found_workflows = []

base_url = 'https://petstore.octoperf.com/actions/Catalog.action'
crawl('https://petstore.octoperf.com/actions/Catalog.action', visited_links, current_workflow, found_workflows,counter,count)

