from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

# Initialize the Selenium web driver
service = Service('./chromedriver')
chrome_options = Options()
chrome_options.add_argument('--headless')
# create a new instance of the Chrome driver
driver = webdriver.Chrome(options=chrome_options)
driver = webdriver.Chrome(service=service)
def get_screenshot(workflow):
    count=1
    base = 'https://petstore.octoperf.com/actions/Catalog.action'
    for url in workflow:
        print("url")
        driver.get(url)
        filename = str(count) + '.png'
        driver.save_screenshot(filename)
        count+=1
    driver.quit()
